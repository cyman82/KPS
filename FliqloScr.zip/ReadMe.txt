Fliqlo 1.6.1 for Windows ReadMe
Updated on May 14, 2026

SYSTEM REQUIREMENTS
Windows 11

INSTALLATION
First, extract the zip file "FliqloScr.zip". Next, right-click the file named "Fliqlo.scr" and select "Install". This will open the Screen Saver settings and set it up. When you install or launch "Fliqlo.scr", a folder named "Fliqlo.scr.WebView2" will be generated in the same directory, but you can ignore it.

UNINSTALLATION
In File Explorer, remove the file named "Fliqlo.scr" installed by the above method.

TERMS OF USE
This software can be used in your home, office, and store. No portion of the software, including the other files in the downloaded zip archive named "FliqloScr.zip", may be redistributed, sold, renamed, converted, or made available for download from websites other than fliqlo.com. Instead, please provide a link to https://fliqlo.com/ if you wish to share the software.

DISCLAIMER
This software is provided to you free of charge. The author gives no warranty in relation to these softwares, and you use them at your own risk. By using or installing the software, you agree to be bound by the terms of this agreement. The author will not be liable for any damage to your system, any loss or corruption of any data or software, or any other loss or damage that you may suffer as a result of downloading or using the software, whether it results from the author's negligence or in any other way.

PRIVACY POLICY
Please check on the fliqlo.com website.

ABOUT YOUR DONATION
If you want to make a donation to support the further development of this software, it is highly appreciated. To donate, double-click the internet shortcut file named "Donate with PayPal.url" in the zip archive named "FliqloScr.zip", or visit the author's PayPal.me page (https://www.paypal.me/yjadc/). You may then enter any amount you wish, and PayPal.me will securely do the rest. Thank you for your support!
* Please refrain from donating less than $1, such as $0.1, as most will be processed as PayPal transaction fees and the actual donation is $0.

ABOUT THE AUTHOR
Yuji Adachi
Indie app creator based in Tokyo, Japan

SUPPORT
Website: https://fliqlo.com/
Email: info@9031.com

© 2026 9031